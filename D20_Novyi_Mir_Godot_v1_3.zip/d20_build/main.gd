extends Node2D

const SCREEN_W: float = 960.0
const SCREEN_H: float = 1600.0

var hero_pos: Vector2 = Vector2(940, 2080)
var hero_target: Vector2 = Vector2(940, 2080)
var pending_object: String = ""
var items: Array[String] = []
var eggs_taken: bool = false
var cooked: bool = false
var eaten: bool = false
var pc_read: bool = false
var plan_saved: bool = false
var portal_seen: bool = false
var fled: bool = false
var coins: int = 320
var message: String = "Нажми на холодильник на кухне, чтобы начать утро."
var ui_layer: CanvasLayer
var panel: Panel
var dialog_title: Label
var dialog_body: Label
var action_buttons: Array[Button] = []
var info_label: Label
var progress_label: Label
var inventory_button: Button
var notebook_button: Button
var dice_button: Button
var rng := RandomNumberGenerator.new()
var apartment: Texture2D
var hero_texture: Texture2D
var dialog_open: bool = false
var selected_name: String = ""
var navigation: AStarGrid2D
var route: Array[Vector2] = []
const CELL: int = 25
const HERO_RADIUS: float = 20.0
const FLOORS: Array[Rect2] = [Rect2(65, 70, 810, 620), Rect2(1020, 70, 785, 620), Rect2(65, 820, 810, 640), Rect2(1020, 820, 785, 640), Rect2(65, 1600, 810, 275), Rect2(1020, 1600, 785, 275), Rect2(65, 2010, 1740, 195), Rect2(905, 50, 65, 2120), Rect2(400, 690, 140, 140), Rect2(1370, 690, 140, 140), Rect2(400, 1460, 140, 150), Rect2(1370, 1460, 140, 150), Rect2(400, 1870, 140, 160), Rect2(1370, 1870, 140, 160), Rect2(850, 450, 175, 115), Rect2(850, 1120, 175, 120), Rect2(850, 1690, 175, 120)]
const BLOCKS: Array[Rect2] = [Rect2(90, 160, 730, 165), Rect2(100, 340, 270, 270), Rect2(480, 340, 340, 280), Rect2(100, 600, 430, 110), Rect2(1100, 175, 455, 335), Rect2(1570, 195, 220, 320), Rect2(1320, 530, 300, 180), Rect2(105, 965, 570, 435), Rect2(710, 960, 150, 220), Rect2(710, 1240, 150, 185), Rect2(1100, 965, 485, 420), Rect2(1620, 980, 165, 320), Rect2(105, 1650, 600, 170), Rect2(730, 1650, 150, 190), Rect2(1100, 1650, 290, 210), Rect2(1480, 1650, 320, 200), Rect2(120, 2075, 330, 120), Rect2(500, 2075, 330, 120), Rect2(1540, 2075, 250, 120)]

const WORLD_SIZE := Vector2(1900, 2300)
var camera_offset: Vector2 = Vector2.ZERO
const HOTSPOTS := {
 "fridge": {"pos": Vector2(255, 480), "radius": 150.0, "name": "Холодильник"},
 "stove": {"pos": Vector2(650, 485), "radius": 165.0, "name": "Плита"},
 "table": {"pos": Vector2(490, 670), "radius": 105.0, "name": "Стол"},
 "laptop": {"pos": Vector2(770, 1040), "radius": 125.0, "name": "Ноутбук"},
 "phone": {"pos": Vector2(780, 1330), "radius": 120.0, "name": "Телефон"},
 "keys": {"pos": Vector2(1625, 2100), "radius": 130.0, "name": "Ключи"},
 "pc": {"pos": Vector2(315, 1720), "radius": 155.0, "name": "Компьютер"},
 "sofa": {"pos": Vector2(1300, 350), "radius": 190.0, "name": "Диван"},
 "bath": {"pos": Vector2(1290, 1150), "radius": 200.0, "name": "Ванная"},
 "toilet": {"pos": Vector2(1220, 1740), "radius": 150.0, "name": "Туалет"},
 "door": {"pos": Vector2(1680, 2120), "radius": 110.0, "name": "Выход"}
}

func _ready() -> void:
 rng.randomize()
 apartment = load("res://assets/apartment.png")
 hero_texture = load("res://assets/hero.png")
 _init_navigation()
 _make_ui()
 _refresh_hud()
 queue_redraw()
 _show_dialog("ГЛАВА 1 · ОБЫЧНЫЙ ДЕНЬ", "Вчера тебя уволили. Сегодня нужно забрать расчёт в офисе, сходить за продуктами и забрать вещи из химчистки. Но сначала — завтрак и сборы.\n\nКасайся пола, чтобы идти. Герой обходит стены и мебель. Касайся предметов, чтобы взаимодействовать.", ["Начать утро"], ["close"])

func _is_walkable(p: Vector2) -> bool:
 var in_floor: bool = false
 for area in FLOORS:
  if area.grow(-HERO_RADIUS).has_point(p):
   in_floor = true
   break
 if not in_floor:
  return false
 for furniture in BLOCKS:
  if furniture.grow(HERO_RADIUS).has_point(p):
   return false
 return true

func _init_navigation() -> void:
 navigation = AStarGrid2D.new()
 navigation.region = Rect2i(0, 0, int(WORLD_SIZE.x / CELL) + 1, int(WORLD_SIZE.y / CELL) + 1)
 navigation.cell_size = Vector2(CELL, CELL)
 navigation.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
 navigation.update()
 for y in range(navigation.region.size.y):
  for x in range(navigation.region.size.x):
   if not _is_walkable(Vector2(x * CELL + CELL / 2, y * CELL + CELL / 2)):
    navigation.set_point_solid(Vector2i(x, y), true)

func _nearest_walkable(p: Vector2) -> Vector2i:
 var base := Vector2i(clampi(int(p.x / CELL), 0, navigation.region.size.x - 1), clampi(int(p.y / CELL), 0, navigation.region.size.y - 1))
 var nearest := base
 var best := INF
 for y in range(maxi(0, base.y - 24), mini(navigation.region.size.y, base.y + 25)):
  for x in range(maxi(0, base.x - 24), mini(navigation.region.size.x, base.x + 25)):
   var cell := Vector2i(x, y)
   if navigation.is_point_solid(cell):
    continue
   var distance := _cell_center(cell).distance_squared_to(p)
   if distance < best:
    best = distance
    nearest = cell
 return nearest

func _cell_center(cell: Vector2i) -> Vector2:
 return Vector2(cell.x * CELL + CELL * 0.5, cell.y * CELL + CELL * 0.5)

func _navigate_to(destination: Vector2, object_key: String = "") -> void:
 var from_cell := _nearest_walkable(hero_pos)
 var candidates: Array[Vector2i] = []
 if object_key == "":
  candidates.append(_nearest_walkable(destination))
 else:
  # Choose an accessible standing position around the object, not inside it.
  var center: Vector2 = HOTSPOTS[object_key]["pos"]
  var radius: float = float(HOTSPOTS[object_key]["radius"])
  for y in range(maxi(0, int((center.y - radius - 90.0) / CELL)), mini(navigation.region.size.y, int((center.y + radius + 90.0) / CELL) + 1)):
   for x in range(maxi(0, int((center.x - radius - 90.0) / CELL)), mini(navigation.region.size.x, int((center.x + radius + 90.0) / CELL) + 1)):
    var cell := Vector2i(x, y)
    if navigation.is_point_solid(cell):
     continue
    var distance := _cell_center(cell).distance_to(center)
    if distance >= radius * 0.6 and distance <= radius + 65.0:
     candidates.append(cell)
 var best_path: Array[Vector2i] = []
 var best_score: float = INF
 for cell in candidates:
  var candidate_path: Array[Vector2i] = navigation.get_id_path(from_cell, cell)
  if candidate_path.is_empty():
   continue
  var score: float = float(candidate_path.size())
  if object_key != "":
   score += _cell_center(cell).distance_to(HOTSPOTS[object_key]["pos"]) / CELL * 0.1
  if score < best_score:
   best_score = score
   best_path = candidate_path
 if best_path.is_empty():
  message = "Путь закрыт. Подойди через дверной проём."
  pending_object = ""
  route.clear()
  _refresh_hud()
  return
 route.clear()
 for cell in best_path:
  route.append(_cell_center(cell))
 pending_object = object_key
 message = "Подходим: " + String(HOTSPOTS[object_key]["name"]) if object_key != "" else "Идём к выбранному месту."
 _refresh_hud()

func _process(delta: float) -> void:
 if not route.is_empty() and not dialog_open:
  var next_pos: Vector2 = hero_pos.move_toward(route[0], delta * 270.0)
  if _is_walkable(next_pos):
   hero_pos = next_pos
  else:
   route.clear()
   pending_object = ""
   message = "Путь перекрыт препятствием."
   _refresh_hud()
  if hero_pos.distance_to(route[0]) < 4.0:
   route.pop_front()
  queue_redraw()
 elif route.is_empty() and pending_object != "" and not dialog_open:
  var target_name: String = pending_object
  pending_object = ""
  _interact(target_name)
 camera_offset = Vector2(clampf(hero_pos.x - 480.0, 0.0, WORLD_SIZE.x - SCREEN_W), clampf(hero_pos.y - 580.0, 0.0, WORLD_SIZE.y - 1170.0))
 queue_redraw()

func _draw() -> void:
 draw_set_transform(-camera_offset)
 if apartment != null:
  draw_texture(apartment, Vector2.ZERO)
 if hero_texture != null:
  draw_texture_rect(hero_texture, Rect2(hero_pos.x - 63, hero_pos.y - 168, 126, 168), false)
 draw_set_transform(Vector2.ZERO)

func _unhandled_input(event: InputEvent) -> void:
 if dialog_open or fled:
  return
 if event is InputEventScreenTouch and event.pressed:
  _tap(event.position)
 elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
  _tap(event.position)

func _tap(pos: Vector2) -> void:
 if pos.y > 1170.0:
  return
 pos += camera_offset
 var chosen: String = ""
 var best_distance: float = 999999.0
 for key in HOTSPOTS.keys():
  var p: Vector2 = HOTSPOTS[key]["pos"]
  var dist: float = pos.distance_to(p)
  if dist < float(HOTSPOTS[key]["radius"]) and dist < best_distance:
   best_distance = dist
   chosen = key
 if chosen != "":
  selected_name = String(HOTSPOTS[chosen]["name"])
  _navigate_to(Vector2(HOTSPOTS[chosen]["pos"]), chosen)
 else:
  _navigate_to(pos)

func _make_ui() -> void:
 ui_layer = CanvasLayer.new()
 add_child(ui_layer)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_IGNORE
 ui_layer.add_child(root)
 var top := ColorRect.new()
 top.color = Color("172337")
 top.mouse_filter = Control.MOUSE_FILTER_IGNORE
 top.position = Vector2(0, 0)
 top.size = Vector2(960, 57)
 root.add_child(top)
 var title := Label.new()
 title.text = "D20  /  НОВЫЙ МИР     •     ГЛАВА 1: КВАРТИРА"
 title.position = Vector2(22, 9)
 title.add_theme_font_size_override("font_size", 25)
 title.add_theme_color_override("font_color", Color("e8f4ff"))
 top.add_child(title)
 var hud := ColorRect.new()
 hud.color = Color("172337")
 hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
 hud.position = Vector2(0, 1170)
 hud.size = Vector2(960, 430)
 root.add_child(hud)
 var accent := ColorRect.new()
 accent.color = Color("3dc4d1")
 accent.mouse_filter = Control.MOUSE_FILTER_IGNORE
 accent.position = Vector2(0, 1170)
 accent.size = Vector2(960, 5)
 root.add_child(accent)
 info_label = Label.new()
 info_label.position = Vector2(26, 1194)
 info_label.size = Vector2(915, 85)
 info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 info_label.add_theme_font_size_override("font_size", 27)
 info_label.add_theme_color_override("font_color", Color("f3f6ff"))
 root.add_child(info_label)
 progress_label = Label.new()
 progress_label.position = Vector2(27, 1293)
 progress_label.size = Vector2(910, 72)
 progress_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 progress_label.add_theme_font_size_override("font_size", 21)
 progress_label.add_theme_color_override("font_color", Color("a7d8e3"))
 root.add_child(progress_label)
 inventory_button = _make_button(root, "РЮКЗАК", Vector2(25, 1412), Vector2(290, 115), "inventory")
 notebook_button = _make_button(root, "ПЛАН НА ДЕНЬ", Vector2(335, 1412), Vector2(330, 115), "notebook")
 dice_button = _make_button(root, "БРОСИТЬ D20", Vector2(683, 1412), Vector2(250, 115), "dice")
 panel = Panel.new()
 panel.position = Vector2(65, 320)
 panel.size = Vector2(830, 790)
 panel.visible = false
 var style := StyleBoxFlat.new()
 style.bg_color = Color("1c2b42")
 style.border_color = Color("61cbd5")
 style.set_border_width_all(5)
 style.set_corner_radius_all(24)
 style.content_margin_left = 25
 panel.add_theme_stylebox_override("panel", style)
 root.add_child(panel)
 dialog_title = Label.new()
 dialog_title.position = Vector2(30, 30)
 dialog_title.size = Vector2(770, 80)
 dialog_title.add_theme_font_size_override("font_size", 34)
 dialog_title.add_theme_color_override("font_color", Color("72e5eb"))
 panel.add_child(dialog_title)
 dialog_body = Label.new()
 dialog_body.position = Vector2(34, 122)
 dialog_body.size = Vector2(760, 390)
 dialog_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 dialog_body.add_theme_font_size_override("font_size", 29)
 dialog_body.add_theme_color_override("font_color", Color("f2f6ff"))
 panel.add_child(dialog_body)
 for i in range(3):
  var b := Button.new()
  b.position = Vector2(32, 525 + i * 78)
  b.size = Vector2(765, 70)
  b.add_theme_font_size_override("font_size", 26)
  panel.add_child(b)
  action_buttons.append(b)

func _make_button(parent: Node, caption: String, pos: Vector2, dimensions: Vector2, action: String) -> Button:
 var b := Button.new()
 b.text = caption
 b.position = pos
 b.size = dimensions
 b.add_theme_font_size_override("font_size", 25)
 b.pressed.connect(_action.bind(action))
 parent.add_child(b)
 return b

func _show_dialog(heading: String, body: String, labels: Array[String], actions: Array[String]) -> void:
 dialog_open = true
 panel.visible = true
 dialog_title.text = heading
 dialog_body.text = body
 for i in range(3):
  var b: Button = action_buttons[i]
  if i < labels.size():
   b.visible = true
   b.text = labels[i]
   for conn in b.pressed.get_connections():
    b.pressed.disconnect(conn["callable"])
   b.pressed.connect(_action.bind(actions[i]))
  else:
   b.visible = false
 _refresh_hud()

func _close_dialog() -> void:
 dialog_open = false
 panel.visible = false
 _refresh_hud()

func _action(action: String) -> void:
 match action:
  "close": _close_dialog()
  "inventory": _inventory()
  "notebook": _notebook()
  "dice": _dice()
  "eggs":
   eggs_taken = true
   message = "Взято: 2 яйца. Теперь нажми на плиту."
   _show_dialog("ХОЛОДИЛЬНИК", "Ты достал два яйца. Следующий шаг — приготовить яичницу на плите.", ["Понятно"], ["close"])
  "cook":
   var roll: int = rng.randi_range(1, 20)
   cooked = true
   message = "Яичница готова. Нажми на обеденный стол."
   _show_dialog("ПРОВЕРКА D20 · ГОТОВКА", "Кубик: " + str(roll) + "/20.\n" + ("Отличная яичница!" if roll >= 11 else "Яичница немного подгорела, но съедобна.") + "\n\nЕда ждёт на столе.", ["Продолжить"], ["close"])
  "eat":
   eaten = true
   message = "Завтрак готов. Собери ноутбук, телефон и ключи."
   _show_dialog("ЗАВТРАК", "Ты позавтракал и восстановил силы.\n\nТеперь собери три предмета в рюкзак: ноутбук, телефон и ключи.", ["К сбору вещей"], ["close"])
  "take_laptop": _take_item("Ноутбук")
  "take_phone": _take_item("Телефон")
  "take_keys": _take_item("Ключи")
  "read_message":
   pc_read = true
   _show_dialog("НОВОЕ СООБЩЕНИЕ", "НЕИЗВЕСТНЫЙ: «Вы ещё не знаете, что произошло. Не открывайте дверь ванной, если услышите три удара».\n\nТы пытаешься ответить, но отправитель уже исчез из сети.", ["Составить план на день", "Закрыть компьютер"], ["notebook", "close"])
  "save_plan":
   plan_saved = true
   message = "План записан. Что за шум доносится из ванной?"
   _show_dialog("ПЛАН СОХРАНЁН", "✓ Химчистка — забрать вещи\n✓ Магазин — купить продукты\n✓ Офис — забрать зарплату\n\nВ этот момент в ванной раздаётся глухой удар. Затем ещё один...", ["Проверить ванную"], ["close"])
  "portal":
   portal_seen = true
   message = "Из ванной доносится жуткий гул. Беги к выходу!"
   _show_dialog("ЧТО В ВАННОЙ?!", "Ты приоткрываешь дверь. Над ванной вращается светящийся разлом. Из темноты тянется чья-то рука.\n\nТретий удар. Свет гаснет. Нужно бежать!", ["Схватить рюкзак и бежать"], ["escape"])
  "escape":
   fled = true
   message = "Глава 1 пройдена. Продолжение — городской квартал."
   _show_dialog("КОНЕЦ ПЕРВОЙ ГЛАВЫ", "Ты вылетаешь в подъезд и захлопываешь дверь.\n\nВ рюкзаке: " + ", ".join(PackedStringArray(items)) + ".\n\nВ ежедневнике остались обычные дела. Но теперь ты знаешь: этот мир не совсем обычный.\n\nСкоро — город и арена.", ["Посмотреть рюкзак", "Посмотреть план"], ["inventory", "notebook"])
 _refresh_hud()

func _take_item(item: String) -> void:
 if not items.has(item):
  items.append(item)
 message = "Предмет «" + item + "» добавлен в рюкзак."
 _show_dialog("ПРЕДМЕТ ПОЛУЧЕН", "Ты положил в рюкзак: " + item + ".\n\nСобрано " + str(items.size()) + "/3 предметов. Нажми «РЮКЗАК», чтобы проверить содержимое.", ["Продолжить"], ["close"])

func _inventory() -> void:
 var contents: String = "Пока пусто."
 if items.size() > 0:
  contents = "• " + "\n• ".join(PackedStringArray(items))
 _show_dialog("РЮКЗАК · ИНВЕНТАРЬ", "Твои вещи:\n" + contents + "\n\n" + str(items.size()) + "/3 предметов для сборов.\nДеньги: " + str(coins) + " ₽", ["Закрыть"], ["close"])

func _notebook() -> void:
 var body: String = "ДЕЛА НА СЕГОДНЯ:\n□ Забрать зарплату в офисе\n□ Забрать одежду из химчистки\n□ Купить продукты в магазине\n\n"
 if plan_saved:
  body += "План записан в ежедневник."
  _show_dialog("ЕЖЕДНЕВНИК", body, ["Закрыть"], ["close"])
 else:
  body += "Записать эти дела в ежедневник?"
  _show_dialog("ЕЖЕДНЕВНИК", body, ["Сохранить план", "Пока не надо"], ["save_plan", "close"])

func _dice() -> void:
 var roll: int = rng.randi_range(1, 20)
 _show_dialog("БРОСОК D20", "Кубик показал: " + str(roll) + " из 20.\n\nВ дальнейшем кубик будет решать исход проверок, диалогов и пошаговых боёв на арене.", ["Закрыть"], ["close"])

func _interact(key: String) -> void:
 match key:
  "fridge":
   if eggs_taken:
    _show_dialog("ХОЛОДИЛЬНИК", "Яйца уже взяты. Теперь нажми на плиту.", ["Закрыть"], ["close"])
   else:
    _show_dialog("ХОЛОДИЛЬНИК", "В холодильнике есть яйца, молоко и сыр. Для завтрака тебе понадобятся два яйца.", ["Взять два яйца", "Закрыть"], ["eggs", "close"])
  "stove":
   if cooked:
    _show_dialog("ПЛИТА", "Яичница уже готова. Можно садиться за стол.", ["Закрыть"], ["close"])
   elif eggs_taken:
    _show_dialog("ПЛИТА", "Сковорода нагрелась. Приготовление решит бросок d20.", ["Бросить d20 и готовить", "Отмена"], ["cook", "close"])
   else:
    _show_dialog("ПЛИТА", "Сначала возьми яйца из холодильника.", ["Понятно"], ["close"])
  "table":
   if cooked and not eaten:
    _show_dialog("ЗАВТРАК", "На столе стоит горячая яичница.", ["Позавтракать", "Позже"], ["eat", "close"])
   elif eaten:
    _show_dialog("СТОЛ", "Ты уже позавтракал.", ["Закрыть"], ["close"])
   else:
    _show_dialog("СТОЛ", "Здесь можно позавтракать, когда приготовишь еду.", ["Закрыть"], ["close"])
  "laptop": _pickup_dialog("Ноутбук", "take_laptop")
  "phone": _pickup_dialog("Телефон", "take_phone")
  "keys": _pickup_dialog("Ключи", "take_keys")
  "pc":
   if not pc_read:
    _show_dialog("КОМПЬЮТЕР", "На мониторе открыты магазин доставки, банковский кабинет и мессенджер.\n\nВ мессенджере мигает новое сообщение от неизвестного контакта.", ["Прочитать сообщение", "Закрыть"], ["read_message", "close"])
   else:
    _show_dialog("КОМПЬЮТЕР", "Доступно: интернет-магазин, банк, ежедневник.\n\nБаланс карты: " + str(coins) + " ₽. Заказы станут доступны в городской главе.", ["Открыть ежедневник", "Закрыть"], ["notebook", "close"])
  "bath":
   if eaten and pc_read and plan_saved:
    _show_dialog("ВАННАЯ КОМНАТА", "Из-за двери слышен странный низкий гул. На кафеле мерцает фиолетовый свет.", ["Заглянуть внутрь", "Отойти"], ["portal", "close"])
   else:
    _show_dialog("ВАННАЯ КОМНАТА", "Пока здесь тихо. Сначала позавтракай, прочитай сообщение на компьютере и составь план на день.", ["Закрыть"], ["close"])
  "door":
   if portal_seen:
    _action("escape")
   else:
    _show_dialog("ВЫХОД ИЗ КВАРТИРЫ", "Прежде чем выходить, стоит закончить утренние дела.", ["Закрыть"], ["close"])
  "sofa": _show_dialog("ГОСТИНАЯ", "Уютный диван. Сегодня не до отдыха: столько дел накопилось после увольнения.", ["Закрыть"], ["close"])
  "toilet": _show_dialog("ТУАЛЕТ", "Обычная ванная сантехника. Ничего необычного... пока что.", ["Закрыть"], ["close"])

func _pickup_dialog(item: String, action: String) -> void:
 if items.has(item):
  _show_dialog(item.to_upper(), "Этот предмет уже лежит в рюкзаке.", ["Закрыть"], ["close"])
 else:
  _show_dialog(item.to_upper(), "Ты нашёл предмет: " + item + ".\n\nПоложить его в рюкзак?", ["Взять", "Оставить"], [action, "close"])

func _refresh_hud() -> void:
 if info_label == null:
  return
 info_label.text = message
 var steps: String = ("✓" if eaten else "□") + " Завтрак   " + str(items.size()) + "/3 вещи   " + ("✓" if pc_read else "□") + " Сообщение   " + ("✓" if plan_saved else "□") + " План"
 progress_label.text = steps + "\nКасайся пола для ходьбы, мебели — для действий."
 queue_redraw()
