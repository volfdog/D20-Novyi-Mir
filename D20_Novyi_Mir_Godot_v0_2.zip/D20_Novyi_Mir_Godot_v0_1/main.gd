extends Node2D

const W: float = 900.0
const H: float = 1600.0
const COLS: int = 5
const ROWS: int = 5
const ORIGIN: Vector2 = Vector2(150, 362)
const STEP: float = 150.0

var city_tex: Texture2D = preload("res://assets/district.png")
var arena_tex: Texture2D = preload("res://assets/arena.png")
var menu_tex: Texture2D = preload("res://assets/menu_art.jpg")
var hero_tex: Texture2D = preload("res://assets/hero.png")
var npc_tex: Texture2D = preload("res://assets/npc.png")
var enemy_tex: Texture2D = preload("res://assets/enemy.png")

var mode: String = "menu"
var hero_cell: Vector2i = Vector2i(2, 3)
var enemy_cell: Vector2i = Vector2i(2, 1)
var hp: int = 28
var enemy_hp: int = 22
var max_hp: int = 28
var ap: int = 2
var turn: int = 1
var gold: int = 20
var medkits: int = 1
var armor: int = 0
var found_cache: bool = false
var quest: bool = false
var message: String = "Выберите режим. Исследуйте район и соберите снаряжение для арены."
var message2: String = "Каждое важное действие решает кубик d20."
var last_roll: int = 0
var battle_over: bool = false
var npc_dialog_open: bool = false

func _ready() -> void:
	get_window().content_scale_factor = 1.0
	queue_redraw()

func _screen_scale() -> Vector2:
	var s: Vector2 = get_viewport_rect().size
	return Vector2(s.x / W, s.y / H)

func _input(event: InputEvent) -> void:
	var p: Vector2 = Vector2(-100, -100)
	if event is InputEventScreenTouch:
		if not event.pressed:
			return
		p = event.position
	elif event is InputEventMouseButton:
		if not event.pressed or event.button_index != MOUSE_BUTTON_LEFT:
			return
		p = event.position
	else:
		return
	var sc: Vector2 = _screen_scale()
	p = Vector2(p.x / sc.x, p.y / sc.y)
	click_at(p)
	queue_redraw()

func _draw() -> void:
	var sc: Vector2 = _screen_scale()
	draw_set_transform(Vector2.ZERO, 0.0, sc)
	draw_rect(Rect2(0, 0, W, H), Color("0c1728"))
	if mode == "menu":
		_draw_menu()
	else:
		_draw_game()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _txt(t: String, x: float, y: float, size: int = 28, c: Color = Color.WHITE) -> void:
	draw_string(ThemeDB.fallback_font, Vector2(x, y), t, HORIZONTAL_ALIGNMENT_LEFT, -1, size, c)

func _panel(r: Rect2, color: Color = Color("13273c"), border: Color = Color("3e7085")) -> void:
	draw_rect(r, color, true)
	draw_rect(r, border, false, 3.0)

func _btn(r: Rect2, t: String, active: bool = true) -> void:
	_panel(r, Color("205a66") if active else Color("263341"), Color("70e1d1") if active else Color("54616a"))
	_txt(t, r.position.x + 22, r.position.y + 65, 30, Color("f2fffd") if active else Color("98a5ae"))

func _draw_menu() -> void:
	draw_texture_rect(menu_tex, Rect2(0, 0, 900, 1120), false)
	draw_rect(Rect2(0, 0, 900, 290), Color(0.03, 0.07, 0.12, 0.86))
	_txt("D20", 85, 115, 91, Color("9efbe8"))
	_txt("НОВЫЙ МИР", 88, 185, 50)
	_txt("Городское фэнтези  •  пошаговая RPG", 90, 238, 25, Color("d7e9e8"))
	_panel(Rect2(0, 1110, 900, 490), Color("101c30"))
	_txt("ОДИН ГЕРОЙ  •  ДВА РЕЖИМА", 70, 1175, 30, Color("b5f7e9"))
	_btn(Rect2(70, 1215, 760, 110), "ИСТОРИЯ — ГОРОДСКОЙ КВАРТАЛ")
	_btn(Rect2(70, 1350, 760, 110), "АРЕНА — ТАКТИЧЕСКИЙ БОЙ")
	_txt("Версия 0.1  •  тестовый игровой прототип", 90, 1535, 22, Color("91aebc"))

func _tile_pos(cell: Vector2i) -> Vector2:
	return ORIGIN + Vector2(float(cell.x) * STEP, float(cell.y) * STEP)

func _draw_game() -> void:
	draw_texture_rect(arena_tex if mode == "arena" else city_tex, Rect2(0, 0, 900, 1120), false)
	# Semi-transparent tactical zones: visible but do not cover the illustrated city.
	for y in range(ROWS):
		for x in range(COLS):
			var center: Vector2 = _tile_pos(Vector2i(x, y))
			var rr: Rect2 = Rect2(center - Vector2(69, 69), Vector2(138, 138))
			draw_rect(rr, Color(0.42, 0.86, 0.79, 0.075), true)
			draw_rect(rr, Color(0.59, 0.95, 0.86, 0.20), false, 2.0)
			if _dist(hero_cell, Vector2i(x, y)) == 1 and ap > 0 and not battle_over:
				draw_rect(rr, Color(0.30, 0.95, 0.74, 0.19), true)
	# NPC only in story; battle enemy only in arena
	if mode == "city":
		_draw_sprite(npc_tex, _tile_pos(Vector2i(1, 1)), 1.0)
		_txt("МИРА  •  НАЖМИ", 180, 421, 23, Color("ffe2a5"))
		if _dist(hero_cell, Vector2i(1, 1)) <= 1:
			draw_arc(_tile_pos(Vector2i(1, 1)) + Vector2(0, 53), 52.0, 0.0, TAU, 45, Color("ffe7a0"), 5.0)
	else:
		if enemy_hp > 0:
			_draw_sprite(enemy_tex, _tile_pos(enemy_cell), 1.0)
			_txt("ПРОТИВНИК", _tile_pos(enemy_cell).x - 69, _tile_pos(enemy_cell).y - 104, 21, Color("ffbdc3"))
	_draw_sprite(hero_tex, _tile_pos(hero_cell), 1.1)
	# hero ring
	var center: Vector2 = _tile_pos(hero_cell)
	draw_arc(center + Vector2(0, 53), 50.0, 0.0, TAU, 45, Color("82ffe0"), 5.0)
	# Header and stats
	_panel(Rect2(0, 0, 900, 170), Color(0.04, 0.09, 0.16, 0.96), Color("438f96"))
	_txt("D20: НОВЫЙ МИР", 35, 58, 40, Color("a8ffe9"))
	_txt("ГОРОД" if mode == "city" else "АРЕНА", 725, 57, 30, Color("ffe5a8"))
	_txt("HP %d/%d   |   ХОД %d   |   ОД %d   |   МОНЕТЫ %d" % [hp, max_hp, turn, ap, gold], 35, 113, 26)
	_txt("АПТЕЧКИ %d   |   БРОНЯ +%d   |   d20 %s" % [medkits, armor, str(last_roll) if last_roll > 0 else "—"], 35, 151, 23, Color("b8d6df"))
	# Message area
	_panel(Rect2(25, 1130, 850, 178), Color("14253a"), Color("426e7f"))
	_txt(message, 49, 1190, 25)
	_txt(message2, 49, 1240, 23, Color("c6dfe5"))
	# Dialogue overlay: keep dialogue visible until player taps the close button.
	if npc_dialog_open and mode == "city":
		_panel(Rect2(48, 690, 804, 330), Color("14263c"), Color("ffd78a"))
		_txt("МИРА — ПЕРВЫЙ КОНТРАКТ", 80, 752, 33, Color("ffe5a8"))
		_txt("Пропал магический модуль со склада.", 80, 816, 27)
		_txt("Отыщи тайник у терминала MANA!", 80, 864, 27)
		_txt("Бросок d20: %d" % last_roll, 80, 916, 29, Color("a5ffdf"))
		_btn(Rect2(510, 932, 310, 72), "ЗАКРЫТЬ")
	# Controls
	if mode == "city":
		_btn(Rect2(30, 1330, 405, 108), "ВЗАИМОДЕЙСТВИЕ")
		_btn(Rect2(465, 1330, 405, 108), "ЗАКОНЧИТЬ ХОД")
		_btn(Rect2(30, 1460, 405, 105), "АПТЕЧКА (+10)", medkits > 0)
		_btn(Rect2(465, 1460, 405, 105), "МЕНЮ")
	else:
		_btn(Rect2(30, 1330, 405, 108), "АТАКА (d20)", not battle_over)
		_btn(Rect2(465, 1330, 405, 108), "КОНЕЦ ХОДА", not battle_over)
		_btn(Rect2(30, 1460, 405, 105), "АПТЕЧКА (+10)", medkits > 0)
		_btn(Rect2(465, 1460, 405, 105), "ГОРОД / МЕНЮ")

func _draw_sprite(tex: Texture2D, at: Vector2, multiplier: float) -> void:
	var width: float = 112.0 * multiplier
	var height: float = 158.0 * multiplier
	draw_texture_rect(tex, Rect2(at.x - width / 2.0, at.y - height + 52.0, width, height), false)

func _dist(a: Vector2i, b: Vector2i) -> int:
	return abs(a.x - b.x) + abs(a.y - b.y)

func _inside(p: Vector2, r: Rect2) -> bool:
	return r.has_point(p)

func click_at(p: Vector2) -> void:
	if mode == "menu":
		if _inside(p, Rect2(70, 1215, 760, 110)):
			mode = "city"
			message = "Квартал Аркана. Поговори с Мирой или найди тайник."
			message2 = "Касайся соседней подсвеченной зоны, чтобы идти."
		elif _inside(p, Rect2(70, 1350, 760, 110)):
			_enter_arena()
		return
	if npc_dialog_open and mode == "city":
		npc_dialog_open = false
		message = "Задание принято. Проверь терминал MANA справа."
		message2 = "Найденное снаряжение пригодится на арене."
		return
	# Tap NPC directly: no extra selection step, no wasted movement.
	if mode == "city" and _inside(p, Rect2(178, 395, 196, 230)):
		_interact_mira()
		return
	if p.y >= 1330:
		var left: bool = p.x < 450.0
		var top: bool = p.y < 1450.0
		if top and left:
			if mode == "city":
				_interact()
			else:
				_attack()
		elif top and not left:
			_end_turn()
		elif not top and left:
			_use_medkit()
		else:
			if mode == "arena":
				mode = "city"
				message = "Ты вернулся в квартал. Награды сохранены."
				message2 = "Исследуй город или возвращайся на арену."
			else:
				mode = "menu"
		return
	if p.y >= 275 and p.y < 1065 and not battle_over:
		var x: int = int(round((p.x - ORIGIN.x) / STEP))
		var y: int = int(round((p.y - ORIGIN.y) / STEP))
		var cell: Vector2i = Vector2i(x, y)
		if x < 0 or x >= COLS or y < 0 or y >= ROWS:
			return
		if ap <= 0:
			message = "Очки действия закончились. Заверши ход."
			message2 = "Нажми «КОНЕЦ ХОДА»."
		elif _dist(hero_cell, cell) == 1:
			if mode == "city" and cell == Vector2i(1, 1):
				_interact_mira()
			elif mode == "arena" and cell == enemy_cell and enemy_hp > 0:
				message = "Клетка занята противником. Нажми «АТАКА»."
				message2 = "Для атаки нужно быть в радиусе двух клеток."
			else:
				hero_cell = cell
				ap -= 1
				message = "Герой переместился. Осталось действий: %d" % ap
				message2 = "Соседние зоны подсвечены бирюзовым."
		else:
			message = "Можно перейти только в соседнюю зону."
			message2 = "Передвижение стоит одно очко действия."

func _interact_mira() -> void:
	var d: int = _dist(hero_cell, Vector2i(1, 1))
	if d > 1:
		message = "Мира далеко: подойди на соседнюю клетку."
		message2 = "Сейчас расстояние %d клеток. Нажми на подсвеченную зону." % d
		return
	if ap <= 0:
		message = "Для разговора нужно 1 ОД. Заверши ход."
		message2 = "Мира ждёт тебя рядом."
		return
	if quest:
		message = "Мира: «Ты уже получил задание. Ищи модуль!»"
		message2 = "Терминал MANA — справа, арена — внизу."
		npc_dialog_open = true
		return
	quest = true
	last_roll = randi_range(1, 20)
	ap -= 1
	if last_roll >= 12:
		gold += 10
	message = "Мира дала задание! Бросок d20: %d." % last_roll
	message2 = "+10 монет за удачное убеждение!" if last_roll >= 12 else "Проверь тайник у терминала MANA."
	npc_dialog_open = true

func _interact() -> void:
	# Always explain which object is being targeted; never silently do nothing.
	if _dist(hero_cell, Vector2i(1, 1)) <= 1:
		_interact_mira()
		return
	if ap <= 0:
		message = "Нет очков действия. Заверши ход."
		message2 = "После нового хода снова будет 2 ОД."
		return
	if _dist(hero_cell, Vector2i(4, 1)) <= 1 and not found_cache:
		last_roll = randi_range(1, 20)
		ap -= 1
		if last_roll >= 9:
			found_cache = true
			medkits += 2
			armor += 2
			message = "Успех d20=%d! Тайник открыт: +2 аптечки." % last_roll
			message2 = "Найдена защитная куртка: броня +2 на арене!"
		else:
			message = "Проверка d20=%d провалена. Замок не поддался." % last_roll
			message2 = "Попробуй ещё раз в следующий ход."
	elif _dist(hero_cell, Vector2i(4, 4)) <= 1:
		_enter_arena()
	else:
		message = "Пока не с кем взаимодействовать."
		message2 = "Подойди к Мире, терминалу MANA или порталу арены."

func _enter_arena() -> void:
	npc_dialog_open = false
	mode = "arena"
	hero_cell = Vector2i(2, 4)
	enemy_cell = Vector2i(2, 1)
	enemy_hp = 22
	ap = 2
	battle_over = false
	message = "Арена! Подойди к сопернику и атакуй через d20."
	message2 = "Броня и аптечки из города доступны в бою."

func _attack() -> void:
	if battle_over or ap <= 0:
		message = "Атака сейчас недоступна."
		return
	if _dist(hero_cell, enemy_cell) > 2:
		message = "Противник далеко. Подойди на две зоны."
		message2 = "Коснись соседней зоны для передвижения."
		return
	last_roll = randi_range(1, 20)
	ap -= 1
	if last_roll + 4 >= 12:
		var damage: int = randi_range(3, 8) + (3 if last_roll == 20 else 0)
		enemy_hp = max(0, enemy_hp - damage)
		message = "d20=%d +4! Попадание: -%d HP врагу." % [last_roll, damage]
		message2 = "Здоровье противника: %d/22" % enemy_hp
		if enemy_hp <= 0:
			gold += 35
			medkits += 1
			battle_over = true
			message = "ПОБЕДА! +35 монет и +1 аптечка."
			message2 = "Возвращайся в город с добычей!"
	else:
		message = "d20=%d +4. Промах! Защита врага: 12." % last_roll
		message2 = "Попробуй атаковать ещё раз."

func _end_turn() -> void:
	if battle_over:
		return
	turn += 1
	ap = 2
	if mode == "arena" and enemy_hp > 0:
		if _dist(hero_cell, enemy_cell) <= 2:
			var roll: int = randi_range(1, 20)
			if roll + 3 >= 12 + armor:
				var damage: int = randi_range(2, 6)
				hp = max(0, hp - damage)
				message = "Враг атакует! d20=%d, урон %d." % [roll, damage]
				message2 = "Твоя броня +%d увеличивает защиту." % armor
				if hp <= 0:
					battle_over = true
					message = "ПОРАЖЕНИЕ. Нажми «ГОРОД / МЕНЮ»."
			else:
				message = "Враг промахнулся! d20=%d." % roll
				message2 = "Теперь твой ход."
		else:
			var dx: int = hero_cell.x - enemy_cell.x
			var dy: int = hero_cell.y - enemy_cell.y
			if abs(dx) > abs(dy):
				enemy_cell.x += 1 if dx > 0 else -1
			else:
				enemy_cell.y += 1 if dy > 0 else -1
			message = "Противник приблизился. Твой ход!"
			message2 = "Осталось %d HP врага." % enemy_hp
	else:
		message = "Новый ход: %d. Доступно два действия." % turn
		message2 = "Ищи экипировку для арены и общайся с жителями."

func _use_medkit() -> void:
	if medkits <= 0 or hp >= max_hp or ap <= 0 or battle_over:
		message = "Аптечку сейчас использовать нельзя."
		return
	medkits -= 1
	ap -= 1
	hp = min(max_hp, hp + 10)
	message = "Аптечка использована: +10 HP (макс. 28)."
	message2 = "Осталось аптечек: %d" % medkits
