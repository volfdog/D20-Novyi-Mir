extends Node2D

const SCREEN_W: float = 960.0
const SCREEN_H: float = 1600.0

var hero_pos: Vector2 = Vector2(410, 1080)
var hero_target: Vector2 = Vector2(410, 1080)
var pending_object: String = ""
var items: Array[String] = []
var eggs_taken: bool = false
var cooked: bool = false
var eaten: bool = false
var pc_read: bool = false
var plan_saved: bool = false
var portal_seen: bool = false
var fled: bool = false
var coins: int = 320
var message: String = "Нажми на холодильник на кухне, чтобы начать утро."
var ui_layer: CanvasLayer
var panel: Panel
var dialog_title: Label
var dialog_body: Label
var action_buttons: Array[Button] = []
var info_label: Label
var progress_label: Label
var inventory_button: Button
var notebook_button: Button
var dice_button: Button
var rng := RandomNumberGenerator.new()
var apartment: Texture2D
var hero_texture: Texture2D
var dialog_open: bool = false
var selected_name: String = ""

const HOTSPOTS := {
 "fridge": {"pos": Vector2(135, 265), "radius": 90.0, "name": "Холодильник"},
 "stove": {"pos": Vector2(341, 260), "radius": 95.0, "name": "Плита"},
 "table": {"pos": Vector2(166, 423), "radius": 85.0, "name": "Обеденный стол"},
 "laptop": {"pos": Vector2(406, 662), "radius": 78.0, "name": "Ноутбук"},
 "phone": {"pos": Vector2(406, 845), "radius": 75.0, "name": "Телефон"},
 "keys": {"pos": Vector2(851, 1069), "radius": 90.0, "name": "Ключи"},
 "pc": {"pos": Vector2(837, 246), "radius": 90.0, "name": "Компьютер"},
 "sofa": {"pos": Vector2(658, 223), "radius": 95.0, "name": "Диван"},
 "bath": {"pos": Vector2(646, 653), "radius": 95.0, "name": "Ванная"},
 "toilet": {"pos": Vector2(606, 909), "radius": 72.0, "name": "Туалет"},
 "door": {"pos": Vector2(852, 1073), "radius": 72.0, "name": "Выход"}
}

func _ready() -> void:
 rng.randomize()
 apartment = load("res://assets/apartment.png")
 hero_texture = load("res://assets/hero.png")
 _make_ui()
 _refresh_hud()
 queue_redraw()
 _show_dialog("ГЛАВА 1 · ОБЫЧНЫЙ ДЕНЬ", "Вчера тебя уволили. Сегодня нужно забрать расчёт в офисе, сходить за продуктами и забрать вещи из химчистки. Но сначала — завтрак и сборы.\n\nКасайся предметов прямо на плане квартиры. Герой подойдёт к ним сам.", ["Начать утро"], ["close"])

func _process(delta: float) -> void:
 if hero_pos.distance_to(hero_target) > 6.0:
  hero_pos = hero_pos.move_toward(hero_target, delta * 460.0)
  queue_redraw()
 elif pending_object != "":
  var target_name: String = pending_object
  pending_object = ""
  _interact(target_name)

func _draw() -> void:
 if apartment != null:
  draw_texture(apartment, Vector2.ZERO)
 for key in HOTSPOTS.keys():
  var obj: Dictionary = HOTSPOTS[key]
  var p: Vector2 = obj["pos"]
  var color := Color(0.28, 0.91, 0.95, 0.68)
  if key == "bath" and plan_saved and pc_read and eaten:
   color = Color(0.79, 0.34, 1.0, 0.88)
  draw_arc(p, 34.0, 0.0, TAU, 32, color, 4.0)
  draw_circle(p, 6.0, color)
 if hero_texture != null:
  draw_texture_rect(hero_texture, Rect2(hero_pos.x - 55, hero_pos.y - 95, 110, 110), false)
 draw_circle(hero_pos + Vector2(0, 15), 10.0, Color(0.22, 0.92, 0.95, 0.55))

func _unhandled_input(event: InputEvent) -> void:
 if dialog_open or fled:
  return
 if event is InputEventScreenTouch and event.pressed:
  _tap(event.position)
 elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
  _tap(event.position)

func _tap(pos: Vector2) -> void:
 if pos.y > 1180.0:
  return
 var chosen: String = ""
 var best_distance: float = 999999.0
 for key in HOTSPOTS.keys():
  var p: Vector2 = HOTSPOTS[key]["pos"]
  var dist: float = pos.distance_to(p)
  if dist < float(HOTSPOTS[key]["radius"]) and dist < best_distance:
   best_distance = dist
   chosen = key
 if chosen != "":
  selected_name = String(HOTSPOTS[chosen]["name"])
  message = "Подходим: " + selected_name
  hero_target = Vector2(HOTSPOTS[chosen]["pos"]) + Vector2(0, 64)
  pending_object = chosen
 else:
  hero_target = Vector2(clampf(pos.x, 70, 885), clampf(pos.y, 105, 1100))
  pending_object = ""
  message = "Идём к выбранному месту."
 _refresh_hud()

func _make_ui() -> void:
 ui_layer = CanvasLayer.new()
 add_child(ui_layer)
 var root := Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter = Control.MOUSE_FILTER_IGNORE
 ui_layer.add_child(root)
 var top := ColorRect.new()
 top.color = Color("172337")
 top.mouse_filter = Control.MOUSE_FILTER_IGNORE
 top.position = Vector2(0, 0)
 top.size = Vector2(960, 57)
 root.add_child(top)
 var title := Label.new()
 title.text = "D20  /  НОВЫЙ МИР     •     ГЛАВА 1: КВАРТИРА"
 title.position = Vector2(22, 9)
 title.add_theme_font_size_override("font_size", 25)
 title.add_theme_color_override("font_color", Color("e8f4ff"))
 top.add_child(title)
 var hud := ColorRect.new()
 hud.color = Color("172337")
 hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
 hud.position = Vector2(0, 1170)
 hud.size = Vector2(960, 430)
 root.add_child(hud)
 var accent := ColorRect.new()
 accent.color = Color("3dc4d1")
 accent.mouse_filter = Control.MOUSE_FILTER_IGNORE
 accent.position = Vector2(0, 1170)
 accent.size = Vector2(960, 5)
 root.add_child(accent)
 info_label = Label.new()
 info_label.position = Vector2(26, 1194)
 info_label.size = Vector2(915, 85)
 info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 info_label.add_theme_font_size_override("font_size", 27)
 info_label.add_theme_color_override("font_color", Color("f3f6ff"))
 root.add_child(info_label)
 progress_label = Label.new()
 progress_label.position = Vector2(27, 1293)
 progress_label.size = Vector2(910, 72)
 progress_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 progress_label.add_theme_font_size_override("font_size", 21)
 progress_label.add_theme_color_override("font_color", Color("a7d8e3"))
 root.add_child(progress_label)
 inventory_button = _make_button(root, "РЮКЗАК", Vector2(25, 1412), Vector2(290, 115), "inventory")
 notebook_button = _make_button(root, "ПЛАН НА ДЕНЬ", Vector2(335, 1412), Vector2(330, 115), "notebook")
 dice_button = _make_button(root, "БРОСИТЬ D20", Vector2(683, 1412), Vector2(250, 115), "dice")
 panel = Panel.new()
 panel.position = Vector2(65, 320)
 panel.size = Vector2(830, 790)
 panel.visible = false
 var style := StyleBoxFlat.new()
 style.bg_color = Color("1c2b42")
 style.border_color = Color("61cbd5")
 style.set_border_width_all(5)
 style.set_corner_radius_all(24)
 style.content_margin_left = 25
 panel.add_theme_stylebox_override("panel", style)
 root.add_child(panel)
 dialog_title = Label.new()
 dialog_title.position = Vector2(30, 30)
 dialog_title.size = Vector2(770, 80)
 dialog_title.add_theme_font_size_override("font_size", 34)
 dialog_title.add_theme_color_override("font_color", Color("72e5eb"))
 panel.add_child(dialog_title)
 dialog_body = Label.new()
 dialog_body.position = Vector2(34, 122)
 dialog_body.size = Vector2(760, 390)
 dialog_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 dialog_body.add_theme_font_size_override("font_size", 29)
 dialog_body.add_theme_color_override("font_color", Color("f2f6ff"))
 panel.add_child(dialog_body)
 for i in range(3):
  var b := Button.new()
  b.position = Vector2(32, 525 + i * 78)
  b.size = Vector2(765, 70)
  b.add_theme_font_size_override("font_size", 26)
  panel.add_child(b)
  action_buttons.append(b)

func _make_button(parent: Node, caption: String, pos: Vector2, dimensions: Vector2, action: String) -> Button:
 var b := Button.new()
 b.text = caption
 b.position = pos
 b.size = dimensions
 b.add_theme_font_size_override("font_size", 25)
 b.pressed.connect(_action.bind(action))
 parent.add_child(b)
 return b

func _show_dialog(heading: String, body: String, labels: Array[String], actions: Array[String]) -> void:
 dialog_open = true
 panel.visible = true
 dialog_title.text = heading
 dialog_body.text = body
 for i in range(3):
  var b: Button = action_buttons[i]
  if i < labels.size():
   b.visible = true
   b.text = labels[i]
   for conn in b.pressed.get_connections():
    b.pressed.disconnect(conn["callable"])
   b.pressed.connect(_action.bind(actions[i]))
  else:
   b.visible = false
 _refresh_hud()

func _close_dialog() -> void:
 dialog_open = false
 panel.visible = false
 _refresh_hud()

func _action(action: String) -> void:
 match action:
  "close": _close_dialog()
  "inventory": _inventory()
  "notebook": _notebook()
  "dice": _dice()
  "eggs":
   eggs_taken = true
   message = "Взято: 2 яйца. Теперь нажми на плиту."
   _show_dialog("ХОЛОДИЛЬНИК", "Ты достал два яйца. Следующий шаг — приготовить яичницу на плите.", ["Понятно"], ["close"])
  "cook":
   var roll: int = rng.randi_range(1, 20)
   cooked = true
   message = "Яичница готова. Нажми на обеденный стол."
   _show_dialog("ПРОВЕРКА D20 · ГОТОВКА", "Кубик: " + str(roll) + "/20.\n" + ("Отличная яичница!" if roll >= 11 else "Яичница немного подгорела, но съедобна.") + "\n\nЕда ждёт на столе.", ["Продолжить"], ["close"])
  "eat":
   eaten = true
   message = "Завтрак готов. Собери ноутбук, телефон и ключи."
   _show_dialog("ЗАВТРАК", "Ты позавтракал и восстановил силы.\n\nТеперь собери три предмета в рюкзак: ноутбук, телефон и ключи.", ["К сбору вещей"], ["close"])
  "take_laptop": _take_item("Ноутбук")
  "take_phone": _take_item("Телефон")
  "take_keys": _take_item("Ключи")
  "read_message":
   pc_read = true
   _show_dialog("НОВОЕ СООБЩЕНИЕ", "НЕИЗВЕСТНЫЙ: «Вы ещё не знаете, что произошло. Не открывайте дверь ванной, если услышите три удара».\n\nТы пытаешься ответить, но отправитель уже исчез из сети.", ["Составить план на день", "Закрыть компьютер"], ["notebook", "close"])
  "save_plan":
   plan_saved = true
   message = "План записан. Что за шум доносится из ванной?"
   _show_dialog("ПЛАН СОХРАНЁН", "✓ Химчистка — забрать вещи\n✓ Магазин — купить продукты\n✓ Офис — забрать зарплату\n\nВ этот момент в ванной раздаётся глухой удар. Затем ещё один...", ["Проверить ванную"], ["close"])
  "portal":
   portal_seen = true
   message = "Из ванной доносится жуткий гул. Беги к выходу!"
   _show_dialog("ЧТО В ВАННОЙ?!", "Ты приоткрываешь дверь. Над ванной вращается светящийся разлом. Из темноты тянется чья-то рука.\n\nТретий удар. Свет гаснет. Нужно бежать!", ["Схватить рюкзак и бежать"], ["escape"])
  "escape":
   fled = true
   message = "Глава 1 пройдена. Продолжение — городской квартал."
   _show_dialog("КОНЕЦ ПЕРВОЙ ГЛАВЫ", "Ты вылетаешь в подъезд и захлопываешь дверь.\n\nВ рюкзаке: " + ", ".join(PackedStringArray(items)) + ".\n\nВ ежедневнике остались обычные дела. Но теперь ты знаешь: этот мир не совсем обычный.\n\nСкоро — город и арена.", ["Посмотреть рюкзак", "Посмотреть план"], ["inventory", "notebook"])
 _refresh_hud()

func _take_item(item: String) -> void:
 if not items.has(item):
  items.append(item)
 message = "Предмет «" + item + "» добавлен в рюкзак."
 _show_dialog("ПРЕДМЕТ ПОЛУЧЕН", "Ты положил в рюкзак: " + item + ".\n\nСобрано " + str(items.size()) + "/3 предметов. Нажми «РЮКЗАК», чтобы проверить содержимое.", ["Продолжить"], ["close"])

func _inventory() -> void:
 var contents: String = "Пока пусто."
 if items.size() > 0:
  contents = "• " + "\n• ".join(PackedStringArray(items))
 _show_dialog("РЮКЗАК · ИНВЕНТАРЬ", "Твои вещи:\n" + contents + "\n\n" + str(items.size()) + "/3 предметов для сборов.\nДеньги: " + str(coins) + " ₽", ["Закрыть"], ["close"])

func _notebook() -> void:
 var body: String = "ДЕЛА НА СЕГОДНЯ:\n□ Забрать зарплату в офисе\n□ Забрать одежду из химчистки\n□ Купить продукты в магазине\n\n"
 if plan_saved:
  body += "План записан в ежедневник."
  _show_dialog("ЕЖЕДНЕВНИК", body, ["Закрыть"], ["close"])
 else:
  body += "Записать эти дела в ежедневник?"
  _show_dialog("ЕЖЕДНЕВНИК", body, ["Сохранить план", "Пока не надо"], ["save_plan", "close"])

func _dice() -> void:
 var roll: int = rng.randi_range(1, 20)
 _show_dialog("БРОСОК D20", "Кубик показал: " + str(roll) + " из 20.\n\nВ дальнейшем кубик будет решать исход проверок, диалогов и пошаговых боёв на арене.", ["Закрыть"], ["close"])

func _interact(key: String) -> void:
 match key:
  "fridge":
   if eggs_taken:
    _show_dialog("ХОЛОДИЛЬНИК", "Яйца уже взяты. Теперь нажми на плиту.", ["Закрыть"], ["close"])
   else:
    _show_dialog("ХОЛОДИЛЬНИК", "В холодильнике есть яйца, молоко и сыр. Для завтрака тебе понадобятся два яйца.", ["Взять два яйца", "Закрыть"], ["eggs", "close"])
  "stove":
   if cooked:
    _show_dialog("ПЛИТА", "Яичница уже готова. Можно садиться за стол.", ["Закрыть"], ["close"])
   elif eggs_taken:
    _show_dialog("ПЛИТА", "Сковорода нагрелась. Приготовление решит бросок d20.", ["Бросить d20 и готовить", "Отмена"], ["cook", "close"])
   else:
    _show_dialog("ПЛИТА", "Сначала возьми яйца из холодильника.", ["Понятно"], ["close"])
  "table":
   if cooked and not eaten:
    _show_dialog("ЗАВТРАК", "На столе стоит горячая яичница.", ["Позавтракать", "Позже"], ["eat", "close"])
   elif eaten:
    _show_dialog("СТОЛ", "Ты уже позавтракал.", ["Закрыть"], ["close"])
   else:
    _show_dialog("СТОЛ", "Здесь можно позавтракать, когда приготовишь еду.", ["Закрыть"], ["close"])
  "laptop": _pickup_dialog("Ноутбук", "take_laptop")
  "phone": _pickup_dialog("Телефон", "take_phone")
  "keys": _pickup_dialog("Ключи", "take_keys")
  "pc":
   if not pc_read:
    _show_dialog("КОМПЬЮТЕР", "На мониторе открыты магазин доставки, банковский кабинет и мессенджер.\n\nВ мессенджере мигает новое сообщение от неизвестного контакта.", ["Прочитать сообщение", "Закрыть"], ["read_message", "close"])
   else:
    _show_dialog("КОМПЬЮТЕР", "Доступно: интернет-магазин, банк, ежедневник.\n\nБаланс карты: " + str(coins) + " ₽. Заказы станут доступны в городской главе.", ["Открыть ежедневник", "Закрыть"], ["notebook", "close"])
  "bath":
   if eaten and pc_read and plan_saved:
    _show_dialog("ВАННАЯ КОМНАТА", "Из-за двери слышен странный низкий гул. На кафеле мерцает фиолетовый свет.", ["Заглянуть внутрь", "Отойти"], ["portal", "close"])
   else:
    _show_dialog("ВАННАЯ КОМНАТА", "Пока здесь тихо. Сначала позавтракай, прочитай сообщение на компьютере и составь план на день.", ["Закрыть"], ["close"])
  "door":
   if portal_seen:
    _action("escape")
   else:
    _show_dialog("ВЫХОД ИЗ КВАРТИРЫ", "Прежде чем выходить, стоит закончить утренние дела.", ["Закрыть"], ["close"])
  "sofa": _show_dialog("ГОСТИНАЯ", "Уютный диван. Сегодня не до отдыха: столько дел накопилось после увольнения.", ["Закрыть"], ["close"])
  "toilet": _show_dialog("ТУАЛЕТ", "Обычная ванная сантехника. Ничего необычного... пока что.", ["Закрыть"], ["close"])

func _pickup_dialog(item: String, action: String) -> void:
 if items.has(item):
  _show_dialog(item.to_upper(), "Этот предмет уже лежит в рюкзаке.", ["Закрыть"], ["close"])
 else:
  _show_dialog(item.to_upper(), "Ты нашёл предмет: " + item + ".\n\nПоложить его в рюкзак?", ["Взять", "Оставить"], [action, "close"])

func _refresh_hud() -> void:
 if info_label == null:
  return
 info_label.text = message
 var steps: String = ("✓" if eaten else "□") + " Завтрак   " + str(items.size()) + "/3 вещи   " + ("✓" if pc_read else "□") + " Сообщение   " + ("✓" if plan_saved else "□") + " План"
 progress_label.text = steps + "\nНажимай на светящиеся отметки у предметов."
 queue_redraw()
